<?php
session_start();
include_once './conexao.php';
//cadastro de pedidos da pagina cadastra-pedido.php
$enviaPedido = filter_input(INPUT_POST, 'EnviaPedido', FILTER_SANITIZE_STRING);
if($enviaPedido){
        $nome = filter_input(INPUT_POST, 'cad_nome', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'cad_email', FILTER_SANITIZE_STRING);
        $tel = filter_input(INPUT_POST, 'cad_tel', FILTER_SANITIZE_STRING);
        $qtd = filter_input(INPUT_POST, 'cad_qtd', FILTER_SANITIZE_STRING);
        
        $query_prod = "INSERT INTO `controlepedido` (`id`, `cad_nome`, `cad_email`, `cad_tel`, `cad_qtd`, `cad_status`) VALUES (NULL, :nome, :mail, :tel, :qtd, 'afazer')";
        
        $cadastrar = $conexao->prepare($query_prod);
        $cadastrar->bindParam(':nome', $nome);
        $cadastrar->bindParam(':email', $email);
        $cadastrar->bindParam(':tel', $tel);
        $cadastrar->bindParam(':qtd', $qtd);
        
        if($cadastrar->execute()){
            $_SESSION['msg'] = "<p>Pedido cadastrado com sucesso.<p>";
            header('Location: panel.php');
        } else {
            $_SESSION['msg'] = "<p>Erro: Pedido não foi cadastrado.<p>";
            header('Location: cadastra-pedido.php');
        }
    }else{
        $_SESSION['msg'] = "<p>Erro: Pedido não foi cadastrado.<p>";
            header('Location: cadastra-pedido.php');
}
//fim do cadastro