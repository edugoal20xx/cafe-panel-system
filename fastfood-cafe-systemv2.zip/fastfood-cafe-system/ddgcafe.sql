-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 03-Set-2020 às 03:55
-- Versão do servidor: 10.4.14-MariaDB
-- versão do PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `ddgcafe`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `controlepedido`
--

CREATE TABLE `controlepedido` (
  `id` int(11) NOT NULL,
  `cad_nome` varchar(225) NOT NULL,
  `cad_email` varchar(225) NOT NULL,
  `cad_tel` varchar(12) NOT NULL,
  `cad_qtd` int(10) NOT NULL,
  `cad_status` set('afazer','emproducao','feito') NOT NULL DEFAULT 'afazer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `controlepedido`
--

INSERT INTO `controlepedido` (`id`, `cad_nome`, `cad_email`, `cad_tel`, `cad_qtd`, `cad_status`) VALUES
(6, 'Billy', 'billybob@billy.com', '11955555555', 1, 'afazer'),
(7, 'Batman', 'desconhecido@desconhecido', '11955551939', 1, 'afazer'),
(8, 'Chuck Norris', 'myth@myth.com', '999999999', 4, 'feito'),
(9, 'Mary', 'mary@mary.com', '11955551212', 2, 'emproducao'),
(10, 'Seiya', 'pegasus.saint@saintseiya.com', '11955101986', 2, 'emproducao'),
(11, 'Robert', 'roberto@roberto.com', '11955123456', 1, 'feito'),
(12, 'Dudu', 'dudu@dudu.com', '11922222222', 10, 'afazer'),
(13, 'Lanzelt', 'Lanzelt@Lanzelt.com', '11944444444', 5, 'afazer'),
(14, 'Testador1', 'testador1@testador1.com', '11967674545', 3, 'afazer');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `controlepedido`
--
ALTER TABLE `controlepedido`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `controlepedido`
--
ALTER TABLE `controlepedido`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
